﻿namespace Exercise_1_MK
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.messageButton = new System.Windows.Forms.Button();
            this.firstButton_Click = new System.Windows.Forms.Button();
            this.secondButton_Click = new System.Windows.Forms.Button();
            this.thirdButton_Click = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // messageButton
            // 
            this.messageButton.Location = new System.Drawing.Point(12, 12);
            this.messageButton.Name = "messageButton";
            this.messageButton.Size = new System.Drawing.Size(107, 50);
            this.messageButton.TabIndex = 0;
            this.messageButton.Text = "Click Me!";
            this.messageButton.UseVisualStyleBackColor = true;
            this.messageButton.Click += new System.EventHandler(this.messageButton_Click);
            // 
            // firstButton_Click
            // 
            this.firstButton_Click.Location = new System.Drawing.Point(12, 79);
            this.firstButton_Click.Name = "firstButton_Click";
            this.firstButton_Click.Size = new System.Drawing.Size(90, 23);
            this.firstButton_Click.TabIndex = 1;
            this.firstButton_Click.Text = "Click button 1";
            this.firstButton_Click.UseVisualStyleBackColor = true;
            this.firstButton_Click.Click += new System.EventHandler(this.button1_Click);
            // 
            // secondButton_Click
            // 
            this.secondButton_Click.Location = new System.Drawing.Point(121, 79);
            this.secondButton_Click.Name = "secondButton_Click";
            this.secondButton_Click.Size = new System.Drawing.Size(91, 23);
            this.secondButton_Click.TabIndex = 2;
            this.secondButton_Click.Text = "Click button 2";
            this.secondButton_Click.UseVisualStyleBackColor = true;
            this.secondButton_Click.Click += new System.EventHandler(this.secondButton_Click_Click);
            // 
            // thirdButton_Click
            // 
            this.thirdButton_Click.Location = new System.Drawing.Point(232, 79);
            this.thirdButton_Click.Name = "thirdButton_Click";
            this.thirdButton_Click.Size = new System.Drawing.Size(104, 23);
            this.thirdButton_Click.TabIndex = 3;
            this.thirdButton_Click.Text = "Click button 3";
            this.thirdButton_Click.UseVisualStyleBackColor = true;
            this.thirdButton_Click.Click += new System.EventHandler(this.thirdButton_Click_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(383, 353);
            this.Controls.Add(this.thirdButton_Click);
            this.Controls.Add(this.secondButton_Click);
            this.Controls.Add(this.firstButton_Click);
            this.Controls.Add(this.messageButton);
            this.Name = "Form1";
            this.Text = "My first project Exercise 1 MK";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button messageButton;
        private System.Windows.Forms.Button firstButton_Click;
        private System.Windows.Forms.Button secondButton_Click;
        private System.Windows.Forms.Button thirdButton_Click;
    }
}

